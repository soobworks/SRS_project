# READ FIRST — ChatGPT handoff

이 ZIP은 팀 Git 저장소의 **읽기 전용 스냅샷**이다. 아래 파일은 원본을 수정하지 않은 복사본이다. 문서가 서로 충돌하더라도 원문 그대로 두고 판단할 것.

## 스냅샷 정보

| 항목 | 값 |
| --- | --- |
| 프로젝트명 | `real-estate-joint-decision-analysis` |
| README 설명 | 둘이 같이 집 고를 때 쓰는 기능. 네이버페이 부동산 역기획. |
| 기준 서비스 (README / team-brief) | 네이버페이 부동산 / 네이버 부동산 — 관심매물 저장 이후 구간 |
| 현재 branch | `soyoung2222` |
| 최신 commit hash | `d0ea82e74ed7d5a4cc3176091c4178ed978b3839` |
| 최신 commit 날짜 | `2026-08-20T10:00:24+09:00` |
| ZIP 생성 시각 | `2026-08-20T10:07:26+09:00` |
| 포함된 주요 폴더 | `docs/`, `decisions/`, `assets/` |
| 전체 docs 개수 | 11개 |
| 복사한 원본 문서 개수 | 18개 (`docs` 11, `decisions` 4, `assets` 2, 루트 `README.md` 1) |
| 이 폴더에 추가된 안내 파일 | `_00_READ_FIRST.md`, `_01_FILE_INDEX.md`, `_02_GIT_SNAPSHOT.md`, `_03_RECENT_CHANGES.md` |
| 이전 handoff 기준 commit | `baf0e5efb0346df58901328f3ce0868231f5d34e` |

원본 저장소 위치: `C:\Users\limit\bproject\real-estate-joint-decision-analysis`  
원본 Git 저장소는 이 ZIP 생성 과정에서 수정하지 않았다.

`docs/01-team-brief.md`의 정본 안내는 다음과 같다: 가설은 `02`, 근거 등급은 `03`, 화면은 `08`, 현재 결정 상태는 `11`. 충돌하면 이 순서로 따른다.

## 추천 읽기 순서

내용을 재구성하지 말고, 아래 파일을 이 순서로 읽을 것.

1. **현재 결정/상태**
   - `docs/11-decision-status.md`
   - `docs/07-cjm-opportunity-score.md` (결정 현황은 `11-decision-status.md`로 분리되어 있음)
2. **Proposal**
   - `README.md`
   - `docs/01-team-brief.md`
   - `assets/proposal.html` (현재 markdown에서 직접 링크되지는 않음. `00-proposal.md`는 이 commit에서 삭제됨)
3. **Hypotheses**
   - `docs/02-hypotheses.md`
4. **Research / Evidence**
   - `docs/03-evidence-log.md` (본문 등급표 + 부록 A 인접 서비스 조사 + 부록 B 검증 이력)
5. **Benchmark**
   - `docs/04-benchmarks.md`
6. **Verification**
   - `docs/03-evidence-log.md` 부록 B (이전 `05-verification-log.md`는 이 commit에서 삭제되고 여기로 합쳐짐)
7. **UX / 화면 / 데이터 연동**
   - `docs/05-tradeoff-patterns.md`
   - `docs/06-cost-model.md`
   - `docs/08-screen-design.md`
   - `docs/09-edge-cases.md`
   - `docs/10-data-integration.md`
   - `assets/reverse-planning.html`
8. **Decisions**
   - `decisions/0001-no-total-score.md`
   - `decisions/0002-two-person-premise.md`
   - `decisions/0003-conditions-belong-to-people.md`
   - `decisions/0004-agreement-by-split.md`

파일 역할과 헤딩 목록은 `_01_FILE_INDEX.md`를 본다.  
이 자료가 어느 시점인지는 `_02_GIT_SNAPSHOT.md`를 본다.  
이전 handoff 이후 변경은 `_03_RECENT_CHANGES.md`를 본다.
