# RECENT CHANGES

이전 handoff 기준 commit: `baf0e5efb0346df58901328f3ce0868231f5d34e`  
현재 최신 commit: `d0ea82e74ed7d5a4cc3176091c4178ed978b3839`

이 구간에 commit은 1개다.

| Commit | 날짜 | 변경 파일 | Commit message |
| --- | --- | --- | --- |
| `d0ea82e74ed7d5a4cc3176091c4178ed978b3839` | 2026-08-20T10:00:24+09:00 | 아래 `git diff --name-status` 목록 전체 | docs: 문서 16개를 11개로 통합하고 정합성 결함 19건 정리 |

`git diff --stat baf0e5efb0346df58901328f3ce0868231f5d34e..HEAD` 요약: 23 files changed, 2129 insertions(+), 2105 deletions(-)

## 이전 Handoff 이후 변경된 파일

`git diff --name-status baf0e5efb0346df58901328f3ce0868231f5d34e..HEAD` 기준.

### 추가

- `docs/03-evidence-log.md`
- `docs/08-screen-design.md`

### 수정

- `README.md`
- `decisions/0001-no-total-score.md`
- `decisions/0002-two-person-premise.md`
- `decisions/0003-conditions-belong-to-people.md`
- `decisions/0004-agreement-by-split.md`
- `docs/04-benchmarks.md`

### 이름 변경 (rename, 내용도 일부 변경)

Git이 rename으로 기록한 항목. 유사도(%)는 git 기록 그대로다.

- `docs/06-team-brief.md` → `docs/01-team-brief.md` (R076)
- `docs/01-hypotheses.md` → `docs/02-hypotheses.md` (R072)
- `docs/07-tradeoff-patterns.md` → `docs/05-tradeoff-patterns.md` (R099)
- `docs/03-cost-model.md` → `docs/06-cost-model.md` (R096)
- `docs/10-cjm-opportunity-score.md` → `docs/07-cjm-opportunity-score.md` (R097)
- `docs/08-edge-cases.md` → `docs/09-edge-cases.md` (R085)
- `docs/14-data-integration.md` → `docs/10-data-integration.md` (R097)
- `docs/15-decision-status.md` → `docs/11-decision-status.md` (R058)

### 삭제

- `docs/00-proposal.md`
- `docs/02-research-2026-08.md`
- `docs/05-verification-log.md`
- `docs/09-evidence-log.md`
- `docs/11-visualization-spec.md`
- `docs/12-invite-and-input-design.md`
- `docs/13-screen-inventory.md`

이 commit에서 변경하지 않은 파일: `assets/proposal.html`, `assets/reverse-planning.html`

## 같은 commit message가 적은 통합 매핑

아래는 commit body에 적힌 문장이다. Cursor가 재해석하지 않았다.

- `00` → `01` 팀 브리프 (기각한 대안·North Star·리스크)
- `02`·`05` → `03` 근거 로그 (부록 A 인접 서비스 조사, 부록 B 검증 이력)
- `11`·`12` → `08` 화면 설계 (1부 입력설계 / 2부 시각화 / 3부 화면목록)
- 전체를 `01`~`11`로 재번호하고 참조 일괄 갱신
